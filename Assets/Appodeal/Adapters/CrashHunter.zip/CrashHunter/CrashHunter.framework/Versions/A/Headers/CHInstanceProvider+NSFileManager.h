//
//  CHInstanceProvider+NSFileManager.h
//  CrashHunter
//
//  Created by Stas Kochkin on 15/12/2016.
//  Copyright © 2016 Appodeal. All rights reserved.
//

#import "CHInstanceProvider.h"

@interface CHInstanceProvider (NSFileManager)

- (NSFileManager *)fileManager;
- (NSString *)documentDirectory;

- (void)archiveRootObject:(id)rootObject toFile:(NSString *)path;
- (id)unarchiveObjectWithFile:(NSString *)path;

- (NSUserDefaults *)standartDefaults;

- (NSString *)uniqFileName;

@end
